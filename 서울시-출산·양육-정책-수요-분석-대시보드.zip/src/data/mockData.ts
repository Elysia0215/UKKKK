/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { PolicyProposal } from '../types';

export const SEOUL_DISTRICTS = [
  '종로구', '중구', '용산구', '성동구', '광진구',
  '동대문구', '중랑구', '성북구', '강북구', '도봉구',
  '노원구', '은평구', '서대문구', '마포구', '양천구',
  '강서구', '구로구', '금천구', '영등포구', '동작구',
  '관악구', '서초구', '강남구', '송파구', '강동구'
];

export const mockProposals: PolicyProposal[] = [
  {
    id: 'PROP-2026-001',
    title: '구립 공공산후조리원 확충 및 이용 대기 기간 단축 건의',
    content: '민간 산후조리원 비용이 너무 비싸서 영세 가정이나 일반 직장인 부부에게 큰 부담이 됩니다. 구립 공공산후조리원이 서울시에 몇 군데 없어서 예약이 하늘의 별 따기입니다. 자치구별로 최소 1개소 이상의 공공산후조리원을 확충하고 저소득층 및 다자녀 가정에 우선 배정 혜택을 늘려주세요.',
    reg_date: '2026-07-15',
    vote_score: 184,
    comment_cnt: 42,
    reply_yn: 'N',
    district: '강북구',
    category: '출산',
    department: ['건강임신지원팀', '가족건강팀']
  },
  {
    id: 'PROP-2026-002',
    title: '다자녀 기준을 3자녀에서 2자녀로 완전히 일원화하고 혜택을 늘려주세요',
    content: '현재 서울시 다자녀 혜택 중 일부는 여전히 3자녀 이상에만 적용되고, 자치구별 주차장 할인이나 공공시설 이용료 감면 기준도 제각각이라 혼선이 있습니다. 저출생 시대에 맞춰 2자녀 가구도 완벽하게 다자녀 혜택(공영주차장 50% 할인, 서울형 다자녀 카드 전면 확대 등)을 받을 수 있도록 조례를 통합해 주세요.',
    reg_date: '2026-07-12',
    vote_score: 245,
    comment_cnt: 67,
    reply_yn: 'N',
    district: '송파구',
    category: '다자녀',
    department: ['저출생사업1팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-003',
    title: '야간 및 주말 영유아 응급실 또는 소아과 진료 기관 지정 요청',
    content: '밤중에 아이가 갑자기 열이 나거나 아플 때 갈 수 있는 소아과가 너무 부족합니다. 달빛어린이병원이 지정되어 있다고는 하지만 우리 자치구에는 하나도 없어 인근 구까지 차를 타고 나가야 합니다. 자치구별로 야간/주말에 운영하는 영유아 진료 기관을 필수 지정하고 인센티브를 부여해 유지해 주세요.',
    reg_date: '2026-07-18',
    vote_score: 312,
    comment_cnt: 89,
    reply_yn: 'N',
    district: '은평구',
    category: '보육',
    department: ['가족건강팀', '돌봄사업팀']
  },
  {
    id: 'PROP-2026-004',
    title: '위기 임산부 익명 출산 및 일시 안심 보호 긴급 쉼터 개설',
    content: '원치 않는 임신이나 경제적 곤란으로 위기에 처한 임산부들이 영아 유기라는 극단적인 선택을 하지 않도록 신원 노출 없이 입소하여 출산하고 일시적으로 보호받을 수 있는 안심 쉼터가 필요합니다. 전문 상담원과의 24시간 연계 채널과 자치구별 긴급 구호 체계를 마련해 주세요.',
    reg_date: '2026-07-10',
    vote_score: 156,
    comment_cnt: 23,
    reply_yn: 'Y',
    district: '관악구',
    category: '위기임산부',
    department: ['아동보호팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-005',
    title: '다문화 가정 자녀를 위한 한국어 교육 및 돌봄 전담 도우미 지원',
    content: '다문화 가정이 늘어나고 있으나 부모의 언어 장벽으로 인해 자녀들이 한글 학습이나 유치원/어린이집 적응에 어려움을 겪고 있습니다. 아이들의 기초 언어 발달을 돕는 전문 도우미를 가정으로 파견하는 서비스나 다문화가족지원센터의 방문 교육 서비스를 확대 운영해 주시기 바랍니다.',
    reg_date: '2026-07-08',
    vote_score: 98,
    comment_cnt: 15,
    reply_yn: 'Y',
    district: '영등포구',
    category: '다문화',
    department: ['다문화지원팀', '돌봄사업팀']
  },
  {
    id: 'PROP-2026-006',
    title: '서울형 유모차 보조금 및 유모차 대여 서비스 자치구 격차 해소',
    content: '어떤 구는 유모차 대여 서비스가 활성화되어 있고 상태도 매우 좋은 반면, 어떤 구는 대여 가능한 유모차가 전혀 없거나 낡은 상태입니다. 서울시 차원에서 통합 유모차 및 영유아 물품 대여 플랫폼을 구축해 자치구 간 불균형을 줄여주세요. 대여 예약도 모바일 앱으로 쉽게 할 수 있게 개선이 필요합니다.',
    reg_date: '2026-07-16',
    vote_score: 142,
    comment_cnt: 31,
    reply_yn: 'N',
    district: '중랑구',
    category: '보육',
    department: ['돌봄사업팀', '저출생사업1팀']
  },
  {
    id: 'PROP-2026-007',
    title: '임산부 교통비 지원 사업 바우처 사용처 확대 (유모차 및 아기용품 구매 허용)',
    content: '서울시에서 지급하는 임산부 교통비 지원금(70만원)은 지하철, 버스, 택시, 유류비로만 사용이 한정되어 있습니다. 출산 직전이나 직후에는 외출이 어려워 교통비를 다 쓰지 못하고 소멸되는 경우가 많습니다. 이 바우처를 유모차, 카시트, 분유 등 육아에 직접 필요한 아기용품 구매에도 사용할 수 있도록 규제를 완화해 주세요.',
    reg_date: '2026-07-14',
    vote_score: 289,
    comment_cnt: 74,
    reply_yn: 'N',
    district: '노원구',
    category: '임신',
    department: ['건강임신지원팀', '저출생사업1팀']
  },
  {
    id: 'PROP-2026-008',
    title: '국공립 어린이집 대기 시간 단축을 위한 단지 내 우선 배정제 개선',
    content: '신축 대단지 아파트 내 국공립 어린이집의 경우 단지 내 주민들에게만 70% 이상 우선권이 주어지다 보니, 인근 다세대/빌라 밀집 지역에 거주하는 아이들은 대기 순번이 밀려 수년째 입소하지 못하는 불합리한 현상이 발생하고 있습니다. 공공 보육 인프라의 혜택이 공평하게 돌아가도록 가점제를 조정해 주세요.',
    reg_date: '2026-07-05',
    vote_score: 165,
    comment_cnt: 48,
    reply_yn: 'Y',
    district: '강동구',
    category: '보육',
    department: ['돌봄사업팀']
  },
  {
    id: 'PROP-2026-009',
    title: '아빠 육아휴직 장려금 지급 대상 확대 및 자치구 통일',
    content: '서초구나 강남구 등 일부 자치구에서는 아빠 육아휴직 시 매월 장려금을 지급하지만 재정 자립도가 낮은 자치구는 혜택이 없거나 매우 적습니다. 태어난 아이와 아빠의 육아 권리는 어느 구에 사느냐에 따라 차별받아서는 안 됩니다. 서울시 예산 매칭을 통해 25개 자치구 모두에서 동등한 아빠 육아휴직 장려금을 받을 수 있도록 일원화해 주세요.',
    reg_date: '2026-07-13',
    vote_score: 220,
    comment_cnt: 55,
    reply_yn: 'N',
    district: '구로구',
    category: '출산',
    department: ['저출생사업1팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-010',
    title: '베이비시터(육아도우미) 신원 보증 및 정부 안심 안심 인증제 도입',
    content: '사설 플랫폼이나 직거래를 통해 아이 돌보미를 구할 때 학대 이력이나 가짜 신원 등에 대한 불안감이 너무 큽니다. 서울시가 베이비시터의 신원, 건강 진단, 아동 학대 전과 등을 직접 검증하고 발급하는 「서울형 안심 육아도우미 인증마크」 제도를 도입해 주십시오. 믿고 맡길 수 있는 환경이 시급합니다.',
    reg_date: '2026-07-17',
    vote_score: 295,
    comment_cnt: 62,
    reply_yn: 'N',
    district: '서초구',
    category: '보육',
    department: ['돌봄사업팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-011',
    title: '임산부 우대 주차구역을 영유아 동반 가정도 사용 가능하도록 변경',
    content: '현재 임산부 전용 주차공간은 임신 중일 때만 스티커를 발부받아 이용할 수 있습니다. 하지만 실제 더 큰 주차 공간이 필요한 시점은 출산 후 무겁고 큰 카시트에서 아기를 승하차시키거나 유모차를 꺼낼 때입니다. 영유아(만 3세 미만)를 동반한 차량도 이 넓은 주차칸을 이용할 수 있도록 주차장 조례를 현실적으로 개정해 주세요.',
    reg_date: '2026-07-11',
    vote_score: 210,
    comment_cnt: 41,
    reply_yn: 'Y',
    district: '마포구',
    category: '임신',
    department: ['건강임신지원팀', '저출생사업1팀']
  },
  {
    id: 'PROP-2026-012',
    title: '다자녀 가구 주거 안정을 위한 서울주택도시공사(SH) 특별 공급 기준 완화',
    content: '현재 SH 다자녀 특별 공급에서 자녀 수 배점 비중이 과도하게 높아, 실제 도심 내 좁은 집에 살며 주거 고통을 겪는 2자녀 무주택 가구가 당첨되기란 불가능에 가깝습니다. 세 자녀 이상 가구뿐만 아니라 서울에 장기 거주한 두 자녀 가구의 가점을 높이고 평형대도 양육에 적합하도록 전용면적 59㎡ 이상 비중을 확보해 주세요.',
    reg_date: '2026-07-06',
    vote_score: 178,
    comment_cnt: 33,
    reply_yn: 'Y',
    district: '양천구',
    category: '다자녀',
    department: ['저출생사업1팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-013',
    title: '청소년 및 대학생 미혼모를 위한 학업 병행 보육 지원 센터 확충',
    content: '갑작스러운 임신과 출산으로 학업을 중단해야 하는 청소년 미혼모나 어린 미혼모 가정이 매우 많습니다. 이들이 아이를 안심하고 맡기면서 검정고시나 대학 수업을 들을 수 있도록 자치구 청소년지원센터나 종합사회복지관 내에 학업 연계형 일시 보육실을 설치하고 장학금 지원을 늘려주세요.',
    reg_date: '2026-07-03',
    vote_score: 115,
    comment_cnt: 19,
    reply_yn: 'Y',
    district: '동작구',
    category: '위기임산부',
    department: ['아동보호팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-014',
    title: '다문화 가정 임산부를 위한 1:1 모국어 출산 코디네이터 연계',
    content: '결혼이민자 여성들이 한국 병원에서 출산할 때 의사소통 문제로 검진 내용을 제대로 이해하지 못하거나 불안해하는 경우가 많습니다. 출산 예정 3개월 전부터 출산 후 1개월까지 전문 자격을 가진 다문화 출산 코디네이터가 동행하며 통역과 한국식 보육 행정 절차를 대행해 주는 밀착 서비스를 청구합니다.',
    reg_date: '2026-07-09',
    vote_score: 130,
    comment_cnt: 25,
    reply_yn: 'N',
    district: '금천구',
    category: '다문화',
    department: ['다문화지원팀', '건강임신지원팀']
  },
  {
    id: 'PROP-2026-015',
    title: '초등 돌봄교실 탈락 아동을 위한 지역아동센터 연계 및 보조금 긴급 지원',
    content: '맞벌이 가정이라 초등 1학년 돌봄교실을 신청했으나 추첨에서 탈락했습니다. 학원을 뺑뺑이 돌릴 수도 없고 퇴사를 고민하고 있습니다. 돌봄교실에서 탈락한 가정이 지역 내 아동센터나 사설 돌봄 시설을 신속하게 이용할 수 있도록 대기 연동 시스템을 마련하고 긴급 돌봄 보조금(바우처)을 차등 지급해 주시길 부탁드립니다.',
    reg_date: '2026-07-16',
    vote_score: 272,
    comment_cnt: 65,
    reply_yn: 'N',
    district: '도봉구',
    category: '보육',
    department: ['돌봄사업팀', '저출생사업1팀']
  },
  {
    id: 'PROP-2026-016',
    title: '난임 시술비 지원 횟수 제한 폐지 및 비급여 항목 지원 확대 요청',
    content: '정부와 서울시에서 난임 시술비를 지원하고 있지만 시술 횟수가 정해져 있어 실패가 반복될수록 부부들의 경제적, 심리적 고통이 가중됩니다. 또한 건강보험이 적용되지 않는 고가의 비급여 주사나 검사 비용은 전액 자부담입니다. 출산 의지가 뚜렷한 난임 부부에게 시술비 횟수 제한을 전면 폐지하고 비급여 항목도 시에서 추가 보조해 주세요.',
    reg_date: '2026-07-14',
    vote_score: 305,
    comment_cnt: 81,
    reply_yn: 'N',
    district: '강남구',
    category: '임신',
    department: ['건강임신지원팀', '가족건강팀']
  },
  {
    id: 'PROP-2026-017',
    title: '서울형 키즈카페 자치구 간 예약 경쟁 완화 및 거주민 우선권 조정',
    content: '서울형 키즈카페가 요금이 저렴하고 안전해서 인기가 많으나 주말 예약은 거의 10초 만에 마감됩니다. 타 지역 구민들이 무분별하게 중복 예약하는 현상이 심각합니다. 해당 자치구 거주민에게 예약 오픈 1일 전 우선 예약 권한을 제공하거나 노쇼(No-Show) 발생 시 페널티 제도를 강력히 도입해 진짜 필요한 관내 육아 가정이 이용하게 해주세요.',
    reg_date: '2026-07-15',
    vote_score: 198,
    comment_cnt: 49,
    reply_yn: 'N',
    district: '성동구',
    category: '보육',
    department: ['돌봄사업팀']
  },
  {
    id: 'PROP-2026-018',
    title: '다자녀 가구 전기요금 및 가스요금 감면 혜택 자동 연동제 건의',
    content: '현재 다자녀 가구로 확정되어도 한전이나 가스회사에 개별적으로 연락하여 증빙 서류를 제출해야 할인을 받을 수 있습니다. 맞벌이 육아로 바쁜 가정에서 신청을 잊어 혜택을 놓치는 일이 허다합니다. 서울시가 행정안전부 및 유관 공공기관과 협력하여, 주민등록상 다자녀 전입 혹은 출생 신고 시 전기·가스·수도 요금 감면이 자동 원스톱 연동되도록 전산망을 연계해 주세요.',
    reg_date: '2026-07-04',
    vote_score: 188,
    comment_cnt: 38,
    reply_yn: 'Y',
    district: '동대문구',
    category: '다자녀',
    department: ['가족지원팀', '저출생사업1팀']
  },
  {
    id: 'PROP-2026-019',
    title: '임산부 단기 긴급 가사 도우미 및 청소 대행 바우처 사업 신설',
    content: '임신 후기나 고위험 임산부의 경우 몸을 가누기 힘들어 집안 청소나 식사 준비 등 가사 노동이 불가능합니다. 남편 역시 생업으로 돕기 힘들 때 사설 가사도우미 비용은 너무 부담스럽습니다. 의사 진단서나 임신 확인서 제출 시 출산 전까지 최소 5회 이상 전문 가사 도우미를 무료 파견하는 가사 돌봄 지원 제도를 도입해 주세요.',
    reg_date: '2026-07-17',
    vote_score: 215,
    comment_cnt: 45,
    reply_yn: 'N',
    district: '광진구',
    category: '임신',
    department: ['건강임신지원팀', '돌봄사업팀']
  },
  {
    id: 'PROP-2026-020',
    title: '베이비 박스 유기 영아 출생 신고 의무화에 따른 위기 산모 익명 상담 강화',
    content: '출생통보제와 보호출산제가 시행되었음에도 여전히 사각지대에서 병원 밖 출산을 한 후 베이비 박스나 길거리에 아이를 남겨두는 위기 산모가 있습니다. 자치구 보건소나 동주민센터에 익명성을 보장하는 전용 긴급 전화와 모바일 오픈채팅 창구를 적극 홍보하고 긴급 생계비와 산후 조리를 보장해 비극적인 영아 유기를 막아주세요.',
    reg_date: '2026-07-07',
    vote_score: 162,
    comment_cnt: 29,
    reply_yn: 'Y',
    district: '서대문구',
    category: '위기임산부',
    department: ['아동보호팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-021',
    title: '다문화 가정을 위한 예방접종 및 영유아 건강검진 다국어 알림 서비스',
    content: '보건소나 소아과에서 오는 영유아 예방접종, 영유아 건강검진 안내 문자가 모두 한국어로만 발송되다 보니 다문화 부모들이 시기를 놓쳐 과태료를 내거나 영아 건강관리에 소홀해지는 사례가 빈번합니다. 서울시 보건소 전산망을 개편하여 부모의 희망 언어(영어, 중국어, 베트남어, 필리핀어 등)로 자동 번역되어 발송되는 맞춤형 다국어 알림톡 시스템을 도입해 주세요.',
    reg_date: '2026-07-02',
    vote_score: 110,
    comment_cnt: 22,
    reply_yn: 'Y',
    district: '구로구',
    category: '다문화',
    department: ['다문화지원팀', '가족건강팀']
  },
  {
    id: 'PROP-2026-022',
    title: '공동육아방(우리동네 키움방) 이용 연령 기준을 현실적으로 만 5세까지 확대',
    content: '현재 저희 구의 공동육아방은 이용 대상을 만 3세 이하 영유아로 제한하고 있습니다. 그러다 보니 첫째(만 4세)와 둘째(만 1세)를 키우는 가정은 아이 둘을 각기 다른 곳에 맡기거나 데려가야 해서 공동육아방을 전혀 이용하지 못하고 있습니다. 형제자매가 동반 입실하는 경우에 한해 이용 기준을 만 5세까지 탄력적으로 적용할 수 있도록 규칙 개정을 건의합니다.',
    reg_date: '2026-07-13',
    vote_score: 145,
    comment_cnt: 30,
    reply_yn: 'N',
    district: '용산구',
    category: '보육',
    department: ['돌봄사업팀']
  },
  {
    id: 'PROP-2026-023',
    title: '출산축하금 지급 방식을 지역사랑상품권 대신 현금이나 카드 바우처로 다각화',
    content: '자치구별로 지급하는 출산축하금이 지역사랑상품권(모바일)으로만 지급되는 경우가 많은데, 사용처가 가맹 학원이나 동네 마트 등으로 고정되어 있어 정작 대형 할인점이나 온라인몰에서 분유, 기저귀를 저렴하게 대량 구매하는 데는 사용하기 어렵습니다. 육아 가정의 가계 실정에 맞추어 상품권 대신 계좌 이체 방식이나 주유/대형마트 이용이 가능한 바우처 카드로 선택해 지급받을 수 있게 개선해 주세요.',
    reg_date: '2026-07-16',
    vote_score: 232,
    comment_cnt: 58,
    reply_yn: 'N',
    district: '강서구',
    category: '출산',
    department: ['저출생사업1팀', '가족지원팀']
  },
  {
    id: 'PROP-2026-024',
    title: '쌍둥이 및 다태아 출산 가정에 대한 전문 도우미 추가 매칭 및 정부 부담 완화',
    content: '최근 난임 시술 증가로 쌍둥이 등 다태아 출생률이 크게 높아졌습니다. 하지만 정부 지원 산모·신생아 건강관리사 지원금은 단태아와 크게 다르지 않고, 도우미 한 분이 아기 둘 이상을 돌보기는 불가능에 가깝습니다. 쌍둥이 가정에는 의무적으로 2인의 건강관리사를 파견하거나 자부담 비율을 80% 이상 전면 시비로 감면하는 정책이 실질적인 저출생 대책입니다.',
    reg_date: '2026-07-19',
    vote_score: 340,
    comment_cnt: 92,
    reply_yn: 'N',
    district: '성북구',
    category: '출산',
    department: ['건강임신지원팀', '가족건강팀', '저출생사업1팀']
  },
  {
    id: 'PROP-2026-025',
    title: '보육교사 담임 수당 인상 및 휴가 대체 인력 서울시 다이렉트 풀(Pool) 운영',
    content: '어린이집 보육교사들이 연차나 병가를 쓰려 해도 대체 교사를 구하기 힘들어 아파도 억지로 일하고 있는 열악한 보육 환경입니다. 구청이나 육아종합지원센터에 등재된 대체 교사 명단은 거의 비활성 상태입니다. 서울시가 직접 급여와 고용을 보장하는 정규직 대체 교사 다이렉트 풀(Pool)을 300명 규모로 상시 운영하여, 어린이집에서 하루 전에 요청하면 신속 파견되도록 공공 파견 시스템을 구축해 주십시오.',
    reg_date: '2026-07-15',
    vote_score: 278,
    comment_cnt: 60,
    reply_yn: 'N',
    district: '중구',
    category: '보육',
    department: ['돌봄사업팀', '저출생사업1팀']
  }
];

// 간단한 형태소 분석이나 사전에 정의된 단어 추출을 시뮬레이션하기 위한 함수
export function extractTopKeywords(proposals: PolicyProposal[]): { keyword: string; count: number }[] {
  // 제목과 본문에서 의미 있는 명사/단어 수집
  const stopWords = new Set([
    '및', '위한', '대해', '있습니다', '수', '하는', '등', '있는', '너무', '없어서', '통해', '제도', '기준', '지원', '서울시', '출산', '육아', '보육', '혜택'
  ]);
  
  const frequencyMap: Record<string, number> = {};
  
  proposals.forEach(prop => {
    const text = (prop.title + ' ' + prop.content).replace(/[.,()[\]'":-]/g, ' ');
    const words = text.split(/\s+/);
    
    words.forEach(word => {
      // 2글자 이상인 단어 중 조사 제거 및 유사 표준화
      let normalized = word.trim();
      if (normalized.length < 2) return;
      
      // 간단한 후처리 (조사 제거)
      if (normalized.endsWith('을') || normalized.endsWith('를') || normalized.endsWith('이') || normalized.endsWith('가') || normalized.endsWith('은') || normalized.endsWith('는')) {
        normalized = normalized.slice(0, -1);
      } else if (normalized.endsWith('으로') || normalized.endsWith('에서') || normalized.endsWith('에게') || normalized.endsWith('과') || normalized.endsWith('와')) {
        normalized = normalized.slice(0, -2);
      }
      
      if (normalized.length < 2) return;
      if (stopWords.has(normalized)) return;
      
      // 핵심 키워드 유인
      if (normalized.includes('공공') || normalized.includes('국공립')) normalized = '공공시설';
      if (normalized.includes('산후조리')) normalized = '산후조리원';
      if (normalized.includes('다자녀') || normalized.includes('2자녀') || normalized.includes('3자녀')) normalized = '다자녀기준';
      if (normalized.includes('유모차')) normalized = '유모차대여';
      if (normalized.includes('어린이집') || normalized.includes('돌봄') || normalized.includes('키즈카페')) normalized = '보육/돌봄';
      if (normalized.includes('응급실') || normalized.includes('소아과') || normalized.includes('응급') || normalized.includes('진료')) normalized = '소아응급의료';
      if (normalized.includes('미혼모') || normalized.includes('임산부') || normalized.includes('산모')) normalized = '임산부지원';
      if (normalized.includes('도우미') || normalized.includes('베이비시터')) normalized = '돌봄인력';
      if (normalized.includes('바우처') || normalized.includes('지원금') || normalized.includes('보조금') || normalized.includes('교통비')) normalized = '직접적바우처';
      if (normalized.includes('예약') || normalized.includes('대기')) normalized = '예약/대기경증';
      
      frequencyMap[normalized] = (frequencyMap[normalized] || 0) + 1;
    });
  });
  
  const sorted = Object.entries(frequencyMap)
    .map(([keyword, count]) => ({ keyword, count }))
    .sort((a, b) => b.count - a.count);
    
  return sorted.slice(0, 5);
}

// 부서별 통계 추출
export function getDepartmentStats(proposals: PolicyProposal[]): { name: string; count: number; unanswered: number }[] {
  const deptMap: Record<string, { count: number; unanswered: number }> = {};
  
  proposals.forEach(prop => {
    prop.department.forEach(dept => {
      if (!deptMap[dept]) {
        deptMap[dept] = { count: 0, unanswered: 0 };
      }
      deptMap[dept].count += 1;
      if (prop.reply_yn === 'N') {
        deptMap[dept].unanswered += 1;
      }
    });
  });
  
  return Object.entries(deptMap).map(([name, stats]) => ({
    name,
    count: stats.count,
    unanswered: stats.unanswered
  })).sort((a, b) => b.count - a.count);
}
